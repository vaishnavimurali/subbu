# This class routes the database operations
# Reference: https://docs.djangoproject.com/en/3.2/topics/db/multi-db/
class DbRouter:
    apps = ['sla_app']

    def db_for_read(self, model, **hints):
        if model._meta.app_label == 'sla_app':
            return 'sla_db'

        return None

    def db_for_write(self, model, **hints):
        if model._meta.app_label == 'sla_app':
            return 'sla_db'

        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        if app_label == 'sla_app':
            return db == 'sla_db'


        return None

    def allow_relation(self, obj1, obj2, **hints):
        print(obj1._meta.app_label, obj2._meta.app_label)
        if obj1._meta.app_label == 'sla_app' and obj2._meta.app_label == 'sla_app':
                return True
        elif 'sla_app' not in [obj1._meta.app_label, obj2._meta.app_label]:
            return True

        return False
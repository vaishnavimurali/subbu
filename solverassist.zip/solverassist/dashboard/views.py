from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model


# def login(request):
#     # if request.method == 'POST':
#     #     username = request.POST['username']
#     #     password = request.POST['password']
#     #     user = authenticate(request, username=username, password=password)

#     #     # if user is not None:
#     #     #         login(request, user)
#     #     # else:
#     #     #         error_message = 'Invalid credentials. Please try again.'
#     #     #         return render(request, 'login.html', {'error_message': error_message})

#     return render(request, 'login.html')


@login_required
def dashboard(request):
    #content = {'username': username}
    return render(request, 'dashboard.html')

def test(request):
      return render(request, 'test.html')
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

@login_required
def sla_app_input(request):
    return render(request,'input.html')

@login_required
def sla_app_output(request):
    return render(request, 'output.html')
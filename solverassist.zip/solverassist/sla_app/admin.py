from django.contrib import admin
from .models import SlaAOWeb, Parameters
# Register your models here.

admin.site.register(SlaAOWeb)
admin.site.register(Parameters)

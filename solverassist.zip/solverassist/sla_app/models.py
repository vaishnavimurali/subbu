from django.db import models

# Create your models here.
class SlaAOWeb(models.Model):
    date=models.DateField()
    achieved=models.CharField(max_length=10)
    breached=models.CharField(max_length=10)
    #parameters_id will be mapped to id of Parameters table
    parameters_id=models.ForeignKey('Parameters', on_delete=models.PROTECT)

    class Meta:
        app_label = 'sla_app'
        db_table = 'sla_aoweb'
        verbose_name = 'SLA AO Web'
        verbose_name_plural = 'SLA AO Web'


    def __str__(self):
        label = str(self.date) + '  | ' + str(self.achieved) + ' | ' + str(self.breached)
        return label
    

class Parameters(models.Model):
    parameters=models.CharField(max_length=100)

    class Meta:
        app_label = 'sla_app'
        db_table = 'parameters'
        verbose_name = 'SLA Parameters'
        verbose_name_plural = 'SLA Parameters'


    def __str__(self):
        return self.parameters
from django.urls import path, include
from . import views

urlpatterns = [
    path('',views.sla_app_input, name='input'),
    path('sla_app_output/',views.sla_app_output, name='output'),
]